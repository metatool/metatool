﻿using Metatool.Plugin;

namespace Metatool.Tools.LibToolDemo
{
    [ToolConfig]
    public class Config
    {
        public string Option1 { get; set; }
        public int    Option2 { get; set; } = 5;
    }
}
